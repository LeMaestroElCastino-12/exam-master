# Feuille de route EXAM MASTER

1. Configurer le dépôt GitHub et Supabase.
2. Développer l'inscription, la connexion et les profils.
3. Construire les cours, exercices, quiz et correction côté serveur.
4. Ajouter les espaces enseignants et administration avec permissions vérifiées.
5. Ajouter suivi des progrès et examens blancs.
6. Intégrer une IA avec limites et modération adaptées aux élèves.
7. Ajouter les paiements via prestataire et webhooks signés, avec accompagnement d'un adulte responsable.
8. Tester sécurité, confidentialité, accessibilité, sauvegardes et déploiement avant commercialisation.
