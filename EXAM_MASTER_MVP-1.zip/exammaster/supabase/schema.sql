-- EXAM MASTER: schéma initial à tester avant toute mise en production.
create extension if not exists pgcrypto;
create table if not exists public.profiles (id uuid primary key references auth.users(id) on delete cascade, full_name text, role text not null default 'student' check (role in ('student','teacher','admin')), created_at timestamptz not null default now());
create table if not exists public.subjects (id uuid primary key default gen_random_uuid(), name text not null unique, created_at timestamptz not null default now());
create table if not exists public.exercises (id uuid primary key default gen_random_uuid(), subject_id uuid references public.subjects(id) on delete set null, title text not null, description text, level text, is_published boolean not null default false, created_at timestamptz not null default now());
create table if not exists public.quiz_questions (id uuid primary key default gen_random_uuid(), exercise_id uuid not null references public.exercises(id) on delete cascade, question text not null, choices jsonb not null default '[]'::jsonb, position integer not null default 0);
create table if not exists public.quiz_answers (id uuid primary key default gen_random_uuid(), question_id uuid not null references public.quiz_questions(id) on delete cascade, answer_text text not null, is_correct boolean not null default false);
create table if not exists public.attempts (id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade, exercise_id uuid references public.exercises(id) on delete set null, score numeric, completed_at timestamptz not null default now());
create table if not exists public.subscriptions (id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade, plan text not null default 'free', status text not null default 'inactive', provider_reference text, created_at timestamptz not null default now());
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into public.profiles(id) values(new.id) on conflict do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
alter table public.profiles enable row level security; alter table public.subjects enable row level security; alter table public.exercises enable row level security; alter table public.quiz_questions enable row level security; alter table public.quiz_answers enable row level security; alter table public.attempts enable row level security; alter table public.subscriptions enable row level security;
create policy "profile owner reads own profile" on public.profiles for select to authenticated using (auth.uid()=id);
create policy "profile owner updates own profile" on public.profiles for update to authenticated using (auth.uid()=id) with check (auth.uid()=id);
create policy "subjects readable" on public.subjects for select to anon, authenticated using (true);
create policy "published exercises readable" on public.exercises for select to anon, authenticated using (is_published=true);
create policy "questions readable for published exercises" on public.quiz_questions for select to anon, authenticated using (exists(select 1 from public.exercises e where e.id=exercise_id and e.is_published=true));
create policy "own attempts readable" on public.attempts for select to authenticated using (auth.uid()=user_id);
create policy "own attempts insert" on public.attempts for insert to authenticated with check (auth.uid()=user_id);
create policy "own subscriptions readable" on public.subscriptions for select to authenticated using (auth.uid()=user_id);
insert into public.subjects(name) values ('Mathématiques'),('Physique-Chimie'),('Français'),('Anglais') on conflict do nothing;
-- IMPORTANT: quiz_answers n'est volontairement pas lisible par les élèves. Ajouter une API serveur de correction avant d'activer les quiz.
