import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'EXAM MASTER — Réussis tes examens', description: 'La plateforme intelligente de préparation aux examens en Afrique francophone.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="fr"><body>{children}</body></html>; }
