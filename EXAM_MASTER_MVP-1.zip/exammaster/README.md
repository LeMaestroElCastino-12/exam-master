# EXAM MASTER

Plateforme éducative de préparation aux examens pour les élèves d'Afrique francophone.

## Démarrage local
1. Installer Node.js 20 ou supérieur.
2. Exécuter `npm install`.
3. Copier `.env.example` vers `.env.local` et renseigner les clés publiques Supabase.
4. Exécuter `npm run dev` puis ouvrir http://localhost:3000.

## Déploiement
Importer ce dépôt dans GitHub puis connecter le dépôt à Vercel. Ajouter les variables d'environnement Supabase dans les paramètres Vercel.

## État du projet
Ce paquet est un socle de démarrage (MVP), pas un SaaS prêt à commercialiser. L'authentification, la correction sécurisée des quiz, les espaces enseignants/administrateurs, l'IA, les paiements, les tests et les contrôles de sécurité restent à développer. Le SQL doit être testé avant production.

Ne jamais publier une clé `service_role` dans le navigateur ni dans une variable `NEXT_PUBLIC_*`. Les clés secrètes ne doivent pas être envoyées dans une conversation.
